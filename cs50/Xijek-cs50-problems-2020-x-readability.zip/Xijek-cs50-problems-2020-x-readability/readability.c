#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main(void)


{
    //ask the user to input a string.
    string(text);
    text = get_string("Text: ");
    float letters = 0, words = 1, sentences = 0;
    //for loop, that will repeat for as long as the text the user inputs.
    for (int i = 0, n = strlen(text); i < n; i++)
    {
        //checks the number of letters the user inputs.
        if (isalpha(text[i]))
        {
            letters++;
            
        }
        //checks the amount of words the user inputs.
        if (isspace(text[i]))
        {
            words++;
        }
        //checks the amount of sentences the user inputs. ispunct does not work here, as any non alphanumeric is counted, for example commas are counted.
        if (text[i] == '.' || text[i] == '?' || text[i] == '!')
        {
            sentences++;
        }
    }
    //Creating a float that calculates the amount of letters per 100 words in the user's input.
    float l = letters / words * 100;
    //Creating a float that calculates the amount of sentences per 100 words in the user's input.
    float s = sentences / words * 100;
    //Using the Coleman-Liau index formula to calculate the grade level of the text the user inputs.
    float index = 0.0588 * l - 0.296 * s - 15.8;
    //create a new version of the index with the number rounded out.
    float indexr = round(index);
    //If the results of the formula fall between 1 and 16, we will print the appropriate grade level to the user.
    if (indexr >= 1 && indexr <= 16)
    {
        printf("Grade %.0f\n", indexr);
    }
    //If the results of the formula fall under 1, we will print Before Grade 1.
    if (indexr < 1)
    {
        printf("Before Grade 1\n");
    }
    //If the results of the formula are over 16, we will print Grade 16+. Else statement didn't work here. Printed both a standard grade and grade 16+.
    if (indexr > 16)
    {
        printf("Grade 16+\n");
    }

}