#include <string.h>
#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>


int main(int argc, string argv[])
{


    //Check that the argument is only two inputs long (./ceasar counts as 1!) and is a number.
    if (argc == 2 && isdigit(*argv[1]))
        
    {
        //Converts the value of the key into an integer.
        int k = atoi(argv[1]); 
        
        //Get the user's text input.
        string p = get_string("plaintext: "); 
        //Print out the cipher.
        printf("ciphertext: "); 

        //A for loop that runs once for every letter of the plaintext.
        for (int i = 0, n = strlen(p) ; i < n; i++)
        {
            //Checking to see if the plaintext is lowercase.
            if (p[i] >= 'a' && p[i] <= 'z')
            {
            //Print the answer in lowercase letters.
                printf("%c", (((p[i] - 'a') + k) % 26) + 'a');
            } 
            //Checking to see if the plaintext is uppercase.
            else if (p[i] >= 'A' && p[i] <= 'Z')
            {
            //Print the answer in uppercase letters.
                printf("%c", (((p[i] - 'A') + k) % 26) + 'A'); 
            }

            else

            {
                printf("%c", p[i]);
            }
        }

        printf("\n");
        return 0;
    }

    else
    {
        printf("Usage: ./caesar k\n");
        return 1;

    }

}