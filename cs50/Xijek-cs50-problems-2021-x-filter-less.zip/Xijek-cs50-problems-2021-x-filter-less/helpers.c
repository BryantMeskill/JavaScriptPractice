#include "helpers.h"
#include <math.h>
#include <stdio.h>
// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //add all pixel colors together then divide by 3 to get the average pixel color.
            //then set each pixel equal to that average to achieve grayscale
            int avg = round((image[i][j].rgbtRed + image[i][j].rgbtBlue + image[i][j].rgbtGreen) / 3.0);
            image[i][j].rgbtRed = image[i][j].rgbtBlue = image[i][j].rgbtGreen = avg;

        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    int max_value = 255;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //use the provided sepia algorithm on each rgb pixel to get the correct coloring for each of r, g, and b
            int sepiaRed = round(.393 * (image[i][j].rgbtRed) + .769 * (image[i][j].rgbtGreen) + .189 * (image[i][j].rgbtBlue));
            int sepiaGreen = round(.349 * (image[i][j].rgbtRed) + .686 * (image[i][j].rgbtGreen) + .168 * (image[i][j].rgbtBlue));
            int sepiaBlue = round(.272 * (image[i][j].rgbtRed) + .534 * (image[i][j].rgbtGreen) + .131 * (image[i][j].rgbtBlue));
            //if the pixel is greater than 255 (max), set it to 255
            if (sepiaRed > max_value)
            {
                sepiaRed = max_value;
            }

            if (sepiaGreen > max_value)
            {
                sepiaGreen = max_value;
            }

            if (sepiaBlue > max_value)
            {
                sepiaBlue = max_value;
            }
            //setting the actual pixel locations to the correct color
            image[i][j].rgbtRed = sepiaRed;
            image[i][j].rgbtGreen = sepiaGreen;
            image[i][j].rgbtBlue = sepiaBlue;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp;

    for (int i = 0; i < height; i++)
    {
        //Setting the for loop to only go halfway through the image.
        //You only need to loop through half the width because we are setting first and last pixels at the same time.
        for (int j = 0; j < width / 2; j++)
        {
            //putting the array into a temporary variable.
            temp = image[i][j];
            //flipping pixel to end i.e. image[0][0] becomes image[0][599]
            //Subtract 1 to ensure you end on last pixel, since the width(j) starts being counted from 0.
            image[i][j] = image[i][width - j - 1];
            //setting the last pixel in the image to the first pixel i.e. image[0][599] becomes image[0][0]
            image[i][width - j - 1] = temp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE copy[height][width];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            copy[i][j].rgbtRed = image[i][j].rgbtRed;
            copy[i][j].rgbtBlue = image[i][j].rgbtBlue;
            copy[i][j].rgbtGreen = image[i][j].rgbtGreen;
            
        }
    }
    
    for (int x = 0; x < height; x++)
    {
        for (int y = 0; y < width; y++)
        {
            //adding the r b and g value of each pixel together and dividing by the sum. round required.
            WORD avgRed = round((copy[x - 1][y - 1].rgbtRed + copy[x - 1][y].rgbtRed + copy[x - 1][y + 1].rgbtRed +
                          copy[x][y - 1].rgbtRed + copy[x][y].rgbtRed + copy[x][y + 1].rgbtRed +
                          copy[x + 1][y - 1].rgbtRed + copy[x + 1][y].rgbtRed + copy[x + 1][y + 1].rgbtRed) / 9.0);
                          
            WORD avgBlue = round((copy[x - 1][y - 1].rgbtBlue + copy[x - 1][y].rgbtBlue + copy[x - 1][y + 1].rgbtBlue +
                          copy[x][y - 1].rgbtBlue + copy[x][y].rgbtBlue + copy[x][y + 1].rgbtBlue +
                          copy[x + 1][y - 1].rgbtBlue + copy[x + 1][y].rgbtBlue + copy[x + 1][y + 1].rgbtBlue) / 9.0);
            
            WORD avgGreen = round((copy[x - 1][y - 1].rgbtGreen + copy[x - 1][y].rgbtGreen + copy[x - 1][y + 1].rgbtGreen +
                          copy[x][y - 1].rgbtGreen + copy[x][y].rgbtGreen + copy[x][y + 1].rgbtGreen +
                          copy[x + 1][y - 1].rgbtGreen + copy[x + 1][y].rgbtGreen + copy[x + 1][y + 1].rgbtGreen) / 9.0);
            //copying the avg for each color to the original array.
            image[x][y].rgbtRed = avgRed;
            image[x][y].rgbtBlue = avgBlue;
            image[x][y].rgbtGreen = avgGreen;
            //left edge of image
            if (y == 0)
            {
                WORD avgLeftEdgeRed = round((copy[x][y].rgbtRed + copy[x - 1][y].rgbtRed + copy[x - 1][y + 1].rgbtRed +
                                           copy[x][y + 1].rgbtRed + copy[x + 1][y + 1].rgbtRed + copy[x + 1][y].rgbtRed) / 6.0);
                                            
                WORD avgLeftEdgeBlue = round((copy[x][y].rgbtBlue + copy[x - 1][y].rgbtBlue + copy[x - 1][y + 1].rgbtBlue +
                                            copy[x][y + 1].rgbtBlue + copy[x + 1][y + 1].rgbtBlue + copy[x + 1][y].rgbtBlue) / 6.0);
                                            
                WORD avgLeftEdgeGreen = round((copy[x][y].rgbtGreen + copy[x - 1][y].rgbtGreen + copy[x - 1][y + 1].rgbtGreen +
                                             copy[x][y + 1].rgbtGreen + copy[x + 1][y + 1].rgbtGreen + copy[x + 1][y].rgbtGreen) / 6.0);
                                            
                image[x][y].rgbtRed = avgLeftEdgeRed;
                image[x][y].rgbtBlue = avgLeftEdgeBlue;
                image[x][y].rgbtGreen = avgLeftEdgeGreen;
            }
            //right edge of image
            if (y == width - 1)
            {
                WORD avgRightEdgeRed = round((copy[x][y].rgbtRed + copy[x - 1][y].rgbtRed + copy[x - 1][y - 1].rgbtRed + 
                                            copy[x][y - 1].rgbtRed + copy[x + 1][y].rgbtRed + copy[x + 1][y - 1].rgbtRed) / 6.0);
                
                WORD avgRightEdgeBlue = round((copy[x][y].rgbtBlue + copy[x - 1][y].rgbtBlue + copy[x - 1][y - 1].rgbtBlue + 
                                             copy[x][y - 1].rgbtBlue + copy[x + 1][y].rgbtBlue + copy[x + 1][y - 1].rgbtBlue) / 6.0);
                
                WORD avgRightEdgeGreen = round((copy[x][y].rgbtGreen + copy[x - 1][y].rgbtGreen + copy[x - 1][y - 1].rgbtGreen + 
                                              copy[x][y - 1].rgbtGreen + copy[x + 1][y].rgbtGreen + copy[x + 1][y - 1].rgbtGreen) / 6.0);
                                            
                image[x][y].rgbtRed = avgRightEdgeRed;
                image[x][y].rgbtBlue = avgRightEdgeBlue;
                image[x][y].rgbtGreen = avgRightEdgeGreen;
            }
            //top edge of image
            if (x == 0)
            {
                WORD avgTopEdgeRed = round((copy[x][y].rgbtRed + copy[x][y + 1].rgbtRed + copy[x][y - 1].rgbtRed +
                                          copy[x + 1][y].rgbtRed + copy[x + 1][y + 1].rgbtRed + copy[x + 1][y - 1].rgbtRed) / 6.0);
                
                WORD avgTopEdgeBlue = round((copy[x][y].rgbtBlue + copy[x][y + 1].rgbtBlue + copy[x][y - 1].rgbtBlue +
                                           copy[x + 1][y].rgbtBlue + copy[x + 1][y + 1].rgbtBlue + copy[x + 1][y - 1].rgbtBlue) / 6.0);
                
                WORD avgTopEdgeGreen = round((copy[x][y].rgbtGreen + copy[x][y + 1].rgbtGreen + copy[x][y - 1].rgbtGreen +
                                            copy[x + 1][y].rgbtGreen + copy[x + 1][y + 1].rgbtGreen + copy[x + 1][y - 1].rgbtGreen) / 6.0);
                                         
                image[x][y].rgbtRed = avgTopEdgeRed;
                image[x][y].rgbtBlue = avgTopEdgeBlue;
                image[x][y].rgbtGreen = avgTopEdgeGreen;
            }
            //bottom edge of image
            if (x == height - 1)
            {
                WORD avgBotEdgeRed = round((copy[x][y].rgbtRed + copy[x][y + 1].rgbtRed + copy[x][y - 1].rgbtRed +
                                          copy[x - 1][y].rgbtRed + copy[x - 1][y + 1].rgbtRed + copy[x - 1][y - 1].rgbtRed) / 6.0);
                
                WORD avgBotEdgeBlue = round((copy[x][y].rgbtBlue + copy[x][y + 1].rgbtBlue + copy[x][y - 1].rgbtBlue +
                                          copy[x - 1][y].rgbtBlue + copy[x - 1][y + 1].rgbtBlue + copy[x - 1][y - 1].rgbtBlue) / 6.0);
                
                WORD avgBotEdgeGreen = round((copy[x][y].rgbtGreen + copy[x][y + 1].rgbtGreen + copy[x][y - 1].rgbtGreen +
                                          copy[x - 1][y].rgbtGreen + copy[x - 1][y + 1].rgbtGreen + copy[x - 1][y - 1].rgbtGreen) / 6.0);
                                          
                image[x][y].rgbtRed = avgBotEdgeRed;
                image[x][y].rgbtBlue = avgBotEdgeBlue;
                image[x][y].rgbtGreen = avgBotEdgeGreen;
                
            }
            //left top corner of image
            if (x == 0 && y == 0)
            {
                WORD avgCornerTopLRed = round((copy[x][y].rgbtRed + copy[x + 1][y].rgbtRed + copy[x + 1][y + 1].rgbtRed + copy[x][y + 1].rgbtRed) / 4.0);
                
                WORD avgCornerTopLBlue = round((copy[x][y].rgbtBlue + copy[x + 1][y].rgbtBlue + copy[x + 1][y + 1].rgbtBlue + copy[x][y + 1].rgbtBlue) / 4.0);
                
                WORD avgCornerTopLGreen = round((copy[x][y].rgbtGreen + copy[x + 1][y].rgbtGreen + copy[x + 1][y + 1].rgbtGreen + copy[x][y + 1].rgbtGreen) / 4.0);
                
                image[x][y].rgbtRed = avgCornerTopLRed;
                image[x][y].rgbtBlue = avgCornerTopLBlue;
                image[x][y].rgbtGreen = avgCornerTopLGreen;
            }
            //left bottom corner of image
            if (x == height - 1 && y == 0)
            {
                WORD avgCornerBotLRed = round((copy[x][y].rgbtRed + copy[x - 1][y].rgbtRed + copy[x - 1][y + 1].rgbtRed + copy[x][y + 1].rgbtRed) / 4.0);
                
                WORD avgCornerBotLBlue = round((copy[x][y].rgbtBlue + copy[x - 1][y].rgbtBlue + copy[x - 1][y + 1].rgbtBlue + copy[x][y + 1].rgbtBlue) / 4.0);
                
                WORD avgCornerBotLGreen = round((copy[x][y].rgbtGreen + copy[x - 1][y].rgbtGreen + copy[x - 1][y + 1].rgbtGreen + copy[x][y + 1].rgbtGreen) / 4.0);
                
                image[x][y].rgbtRed = avgCornerBotLRed;
                image[x][y].rgbtBlue = avgCornerBotLBlue;
                image[x][y].rgbtGreen = avgCornerBotLGreen;
            }
            //right top corner of image
            if (x == 0 && y == width - 1)
            {
                WORD avgCornerTopRRed = round((copy[x][y].rgbtRed + copy[x + 1][y].rgbtRed + copy[x + 1][y - 1].rgbtRed + copy[x][y - 1].rgbtRed) / 4.0);
                
                WORD avgCornerTopRBlue = round((copy[x][y].rgbtBlue + copy[x + 1][y].rgbtBlue + copy[x + 1][y - 1].rgbtBlue + copy[x][y - 1].rgbtBlue) / 4.0);
                
                WORD avgCornerTopRGreen = round((copy[x][y].rgbtGreen + copy[x + 1][y].rgbtGreen + copy[x + 1][y - 1].rgbtGreen + copy[x][y - 1].rgbtGreen) / 4.0);
                
                image[x][y].rgbtRed = avgCornerTopRRed;
                image[x][y].rgbtBlue = avgCornerTopRBlue;
                image[x][y].rgbtGreen = avgCornerTopRGreen;
            }
            //right bottom corner of image
            if (x == height - 1 && y == width - 1)
            {
                WORD avgCornerBotRRed = round((copy[x][y].rgbtRed + copy[x - 1][y].rgbtRed + copy[x - 1][y - 1].rgbtRed + copy[x][y - 1].rgbtRed) / 4.0);
                
                WORD avgCornerBotRBlue = round((copy[x][y].rgbtBlue + copy[x - 1][y].rgbtBlue+ copy[x - 1][y - 1].rgbtBlue + copy[x][y - 1].rgbtBlue) / 4.0);
                
                WORD avgCornerBotRGreen = round((copy[x][y].rgbtGreen + copy[x - 1][y].rgbtGreen + copy[x - 1][y - 1].rgbtGreen + copy[x][y - 1].rgbtGreen) / 4.0);
                
                image[x][y].rgbtRed = avgCornerBotRRed;
                image[x][y].rgbtBlue = avgCornerBotRBlue;
                image[x][y].rgbtGreen = avgCornerBotRGreen;
            }
        }
    }
    return;
}
