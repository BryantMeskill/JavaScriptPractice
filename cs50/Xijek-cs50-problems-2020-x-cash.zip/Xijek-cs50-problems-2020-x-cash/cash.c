#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)

{
    
    float dollar;
    int cent;

    //Prompt the user for change owed, reprompting the user if they input a negative value.
    do
    {
        dollar = get_float("Change owed:");
        cent = round(dollar * 100);
    }
        while (dollar < 0.0);

        //Creating the variable for total coins needed.
        int coins = 0;

        //While the total is greater than 25, take 25 away from the cent variable, while adding 1 to the coins variable.
        while (cent >= 25)
        {   
            coins++;
            cent = cent - 25;
        }

        //While the total is greater than 10 but less than 25, take 10 away from the cent variable, while adding 1 to the coins variable.
        while (cent >= 10 && cent < 25)
        {
            coins++;
            cent = cent - 10;
        }

        //While the total is greater than 5 but less than 10, take away 5 from the cent variable, while adding 1 to the coins variable.
        while (cent >= 5 && cent < 10)
        {
            coins++;
            cent = cent - 5;
        }

        //While the total is greater than 1 but less than 5, take away 1 from the cent variable, while adding 1 to the coins variable.
        while (cent >= 1 && cent < 5)
        {
            coins++;
            cent = cent - 1;
        }

        //Prints the output to user, declaring minimum number of coins required for correct change.
        printf("Minimum number of coins required: %i\n", coins);
}
