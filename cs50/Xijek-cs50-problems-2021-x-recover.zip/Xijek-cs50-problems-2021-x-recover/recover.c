#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
 
int main(int argc, char *argv[])
{
    typedef uint8_t BYTE;
    
    if (argc != 2)
    {
        printf("Usage: ./recover image\n");
        return 1;
    }
    //opening the card filled with the images
    FILE *card = fopen(argv[1], "r");
    if (card == NULL)
    {
        printf("Could not open file.\n");
        return 2;
    }
    //creating a file for later
    FILE *newfile = NULL;
    BYTE buffer[512];
    int jpeg = 0;
    int jpeg_counter = 0;
    while (fread(buffer, sizeof(BYTE), 512, card) != 0)
    { 
        //verifying the file header is in line with what is expected from a jpeg.
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {   
            //If jpeg is equal to 1, that means we have already written out a jpeg. close the current file, and set jpeg to 0
            //to start the next if statement, creating a new jpeg.
            if (jpeg == 1)
            {
                fclose(newfile);
                jpeg = 0;
            }
            //if starting a new jpeg, create a buffer for the string length of sprintf, create a variable for the name of the image, increment it
            //and set jpeg to 1. 
            if (jpeg == 0)
            {
                char buff[8];
                sprintf(buff, "%03i.jpg", jpeg_counter);
                newfile = fopen(buff, "w");
                jpeg_counter++;
                jpeg = 1;
            }
        }
        //newfile has been opened, so we can now write a new jpeg.
        if (jpeg == 1)
        {
            fwrite(buffer, sizeof(BYTE), 512, newfile);
        }
    }
    fclose(card);
    fclose(newfile);
}