#include <cs50.h>
#include <stdio.h>

int main(void)

{
    int n;
    //prompt the user for an integer no greater than 8, and no less than 1.
    do
    {
        n = get_int("Height: ");
    }
    while (n > 8 || n < 1);
    //while i is less than n, execute the below for loops.
    for (int i = 0; i < n; i++)
    {
        //this loop prints spaces per line, I.E. if the user inputs 8, 7 spaces on line 1, 6 spaces on line 2, etc.
        for (int j = n - 1; j > i; j--)
        {
            printf(" ");
        }
        //this loop adds a pound for each line. 
        for (int k = -1; k < i; k++)
        {
            printf("#");
        }
        //prints the spaces between the pyramids.
        {
            printf("  ");
        }
        //this loop is for building the left-aligned pyramid.
        for (int m = -1; m < i; m++)
        {
            printf("#");
        }
            
        {
            printf("\n");
        }
    }
}
