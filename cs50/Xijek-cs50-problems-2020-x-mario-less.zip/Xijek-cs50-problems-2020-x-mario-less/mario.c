#include <stdio.h>
#include <cs50.h>

int main(void)

{
    int n;
    //Asking the user to declare a variable no more than 8, and no less than 1.
    do
    { 
        n = get_int("Height: ");
    }
    while (n > 8 || n < 1);
    //Creating the triangle with a for loop. While i is less than n, repeat the below. 'i' is incremented up by 1 each cycle, via i++
    for(int i = 0; i < n; i++)
    {
        //Visulaize this. n - 1 = 5, so 5 empty spaces at the top of the pyramid, and so forth. 
        for(int j = n - 1; j > i; j--)
        {
            printf(" ");
        }
        for(int k = -1; k < i; k++)
        {
            printf("#");
        }
        //Ending the program with a new line.
        printf("\n");
    }
}
